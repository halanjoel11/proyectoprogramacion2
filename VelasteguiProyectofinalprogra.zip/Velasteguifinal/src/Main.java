import java.util.ArrayList;
import java.util.List;
import java.util.Scanner;

class Proyecto {
    private String nombre;
    private int progreso;
    private List<String> tareas;
    private List<String> encargados;

    public Proyecto(String nombre) {
        this.nombre = nombre;
        this.progreso = 0;
        this.tareas = new ArrayList<>();
        this.encargados = new ArrayList<>();
    }

    public String getNombre() {
        return nombre;
    }

    public int getProgreso() {
        return progreso;
    }

    public List<String> getTareas() {
        return tareas;
    }

    public List<String> getEncargados() {
        return encargados;
    }

    public void agregarAsignacion(String tarea, String encargado) {
        tareas.add(tarea);
        encargados.add(encargado);
        actualizarProgreso();
    }

    private void actualizarProgreso() {
        int tareasCompletadas = tareas.size(); // En este ejemplo, siempre consideramos que la tarea está completa.
        progreso = (int) (((double) tareasCompletadas / tareas.size()) * 100);
    }

    @Override
    public String toString() {
        StringBuilder proyectoString = new StringBuilder("Proyecto: " + nombre + "\nProgreso: " + progreso + "%\nAsignaciones:\n");
        for (int i = 0; i < tareas.size(); i++) {
            proyectoString.append("- Tarea: ").append(tareas.get(i)).append(", Encargado: ").append(encargados.get(i)).append("\n");
        }
        return proyectoString.toString();
    }
}

class ListaDeProyectos {
    private List<Proyecto> proyectos;

    public ListaDeProyectos() {
        this.proyectos = new ArrayList<>();
    }

    public void agregarProyecto(Proyecto nuevoProyecto) {
        proyectos.add(nuevoProyecto);
    }

    public void mostrarProyectos() {
        if (proyectos.isEmpty()) {
            System.out.println("Aun no se crean Proyectos");
        } else {
            System.out.println("Proyectos:");
            for (Proyecto proyecto : proyectos) {
                System.out.println(proyecto);
            }
        }
    }
}
class GestionProyectos {
    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);

        ListaDeProyectos listaProyectos = new ListaDeProyectos();

        while (true) {
            System.out.println("1) Crear Nuevo Proyecto");
            System.out.println("2) Ver Proyectos Guardados");
            System.out.println("0) Salir");

            int opcion = scanner.nextInt();
            scanner.nextLine();

            switch (opcion) {
                case 1:
                    System.out.print("Ingrese el nombre del nuevo proyecto: ");
                    String nombreProyecto = scanner.nextLine();

                    Proyecto nuevoProyecto = new Proyecto(nombreProyecto);

                    while (true) {
                        System.out.print("Ingrese el nombre de la tarea:\nPulse 0 para volver al menu ");
                        String tarea = scanner.nextLine();

                        if (tarea.equals("0")) {
                            break;
                        }

                        System.out.print("A quien se le asigna esta tarea: ");
                        String encargado = scanner.nextLine();

                        nuevoProyecto.agregarAsignacion(tarea, encargado);
                    }

                    listaProyectos.agregarProyecto(nuevoProyecto);

                    break;
                case 2:
                    listaProyectos.mostrarProyectos();
                    break;
                case 0:
                    System.out.println("Saliending, Gracias por usar");
                    scanner.close();
                    System.exit(0);
                default:
                    System.out.println("Ingrese un valor dentro del rango");
            }
        }
    }
}
